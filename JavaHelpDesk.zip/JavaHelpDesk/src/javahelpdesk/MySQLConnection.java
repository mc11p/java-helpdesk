/*
 * Name: MySQLConnection - Class
 * Description: Handles database connections & data fetching
 *          +Extended by other classes for data fetching
 */
package javahelpdesk;
import java.sql.*;
import java.util.Vector;

/**
 *
 * @author B00297681
 */
public class MySQLConnection {
    
    /*
     * getConnection() returns Database connection.
     * DriverManager.getConnection("dbURL, dbUserName, dbPassword");
     * 
     * Details:
     *  URL: jdbc:mysql://localhost:3306/
     *  Username: admin
     *  Password: admin123
     *
     */
    protected Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/?user=admin", "admin", "admin123");
    }
    
    /*
     * Method: getUserID()
     * Description: Fetch user ID(specified by username - username is unique)
     *      returns 0 for No user ID found
     *      else
     *      returns User ID found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected int getUserID(String username) throws SQLException { //only called once client is logged into ClientPanel. So it assumed the User MUST exist. No usernameExist() checks made.
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT user_id FROM helpdesk_schema.user_table WHERE (user_name = '"+username+"')");
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            int userID;
            userID = rs.getInt("user_id");
            System.out.println("Found userID: "+userID);
            return userID;
        } else {
            return 0;
        }
    }
    
    /*
     * Method: getUserEmail()
     * Description: Fetch user Email(specified by username - username is unique)
     *      returns "No  email" for No user email
     *      else
     *      returns User Email found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected String getUserEmail(String username) throws SQLException { 
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT user_email FROM helpdesk_schema.user_table WHERE (user_name = '"+username+"')");
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            String userEmail;
            userEmail = rs.getString("user_email");
            System.out.println("Found userEmail: "+userEmail);
            return userEmail;
        } else {
            return "No email";
        }
    }
    
    /*
     * Method: getTicketID()
     * Description: Fetch ticket ID(specified by ticket number) for a specified user (specified by userID)
     *      returns 0 for No ticket ID found
     *      else
     *      returns Ticket ID found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected int getTicketID(int ticketNo, int userID) throws SQLException { //only called once client is logged into ClientPanel. So it assumed the User MUST exist. No usernameExist() checks made.
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT ticket_id FROM helpdesk_schema.ticket_table WHERE (ticket_Number = '"+ticketNo+"' AND user_id = '"+userID+"')");
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            int ticketID;
            ticketID = rs.getInt("ticket_id");
            System.out.println("Found ticketID: "+ticketID);
            return ticketID;
        } else {
            return 0;
        }
    }
    
    /*
     * Method: getTicketTitle()
     * Description: Fetch ticket title(specified by ticket number) for a specified user (specified by userID)
     *      returns "Open Ticket!" for No ticket title found
     *      else
     *      returns Ticket Title found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected String getTicketTitle(int userID, int ticketNumber) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT ticket_title FROM helpdesk_schema.ticket_table WHERE user_id = "+userID+" AND ticket_number = "+ticketNumber);
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            System.out.println("Found ticket title: "+rs.getString("ticket_title"));
            return rs.getString("ticket_title");
        } else {
            return "No Ticket";
        }
        
    }
    
    /*
     * Method: getTicketStatus()
     * Description: Fetch ticket status(specified by ticket number) for a specified user (specified by userID)
     *      returns "No Ticket" for No ticket status
     *      else
     *      returns Ticket Status found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected String getTicketStatus(int userID, int ticketNumber) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT ticket_status FROM helpdesk_schema.ticket_table WHERE user_id = "+userID+" AND ticket_number = "+ticketNumber);
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) { 
            System.out.println("Found ticket status: "+rs.getString("ticket_status"));
            return rs.getString("ticket_status");
        } else {
            return "No Ticket";
        }
    }
    
    /*
     * Method: getTicketDescription()
     * Description: Fetch ticket description(specified by ticket number) for a specified user(specified by userID)
     *      returns "Enter description here." for No ticket description
     *      else
     *      returns Ticket Description found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected String getTicketDescription(int userID, int ticketNumber) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT ticket_description FROM helpdesk_schema.ticket_table WHERE user_id = "+userID+" AND ticket_number = "+ticketNumber);
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) { 
            return rs.getString("ticket_description");
        } else {
            return "Enter description here.";
        }
    }
    
    /*
     * Method: getTicketReply()
     * Description: Fetch ticket reply(specified by ticket number) for a specified user(specified by userID)
     *      returns "Awaiting Reply" for No ticket reply
     *      else
     *      returns Ticket Reply found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected String getTicketReply(int userID, int ticketNumber) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT ticket_reply FROM helpdesk_schema.ticket_table WHERE user_id = "+userID+" AND ticket_number = "+ticketNumber);
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) { 
            return rs.getString("ticket_reply");
        } else {
            return "Awaiting Reply";
        }
    }
    
    /*
     * Method: getTicketCount()
     * Description: Fetch ticket count for a specified user(specified by userID)
     *      returns "0" for No ticket count
     *      else
     *      returns Ticket count found from database
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected int getTicketCount(int userID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT user_noOfTickets FROM helpdesk_schema.user_table WHERE user_id = "+userID);
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) { 
            return rs.getInt("user_noOfTickets");
        } else {
            return 0;
        }
    }
    
    /*
     * Method: getUserTable()
     * Description: 
     *      returns ResultSet for SQL SELECT statement:
     *      user_id, user_name, user_noOfTickets, user_priority
     *      Orders by Ascending for user_priority
     */
    protected ResultSet getUserTable() throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT `user_id` AS `User_ID`, `user_name` AS `User_Name`, `user_noOfTickets` AS `Total Tickets`, `user_priority` AS `Priority` FROM helpdesk_schema.user_table ORDER BY user_priority DESC");
        ResultSet rs = statement.executeQuery(sql);
        return rs;
        }
    
    /*
     * Method: getUserList()
     * Description: 
     *      returns ResultSet for SQL SELECT statement:
     *      user_name
     */
    protected Vector<String> getUserList() throws SQLException {
        Vector<String> users = new Vector<String>();
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT `user_name` AS `User_Name` FROM helpdesk_schema.user_table");
        ResultSet rs = statement.executeQuery(sql);
        while(rs.next()) {
            users.add(rs.getString("user_name"));
        }
        return users;
    }
    /*
     * Method: emailExists()
     * Description: Checks whether an email exists
     *      returns true for email found
     *      else
     *      returns false for email not found
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected boolean emailExists(String email) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT user_email FROM helpdesk_schema.user_table WHERE (user_email = '"+email+"')");
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            System.out.println("Finding email: "+rs.getString("user_email"));
            if(rs.getString("user_email").equals(email)) {
                System.out.println("MATCH.");
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
    
    /*
     * Method: usernameExists()
     * Description: Checks whether a username exists
     *      returns true for username found
     *      else
     *      returns false for username not found
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected boolean usernameExists(String username) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql = ("SELECT user_name FROM helpdesk_schema.user_table WHERE (user_name = '"+username+"')");
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            System.out.println("Finding username: "+rs.getString("user_name"));
            if(rs.getString("user_name").equals(username)) {
                System.out.println("MATCH.");
                return true;
            }
        }
        return false;
    }
    
    /*
     * Method: passwordExists()
     * Description: Checks whether a password exists
     *      returns true for password found
     *      else
     *      returns false for passoword not found
     *      + SQL SELECT statement (uses parameters to for variables)
     */
    protected boolean passwordExists(String password, String username) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "SELECT user_password FROM helpdesk_schema.user_table WHERE (user_password = '"+password+"' AND user_name = '"+username+"')";
        ResultSet rs = statement.executeQuery(sql);
        if(rs.next()) {
            System.out.println("Finding password: "+rs.getString("user_password"));
            if(rs.getString("user_password").equals(password)) {
                System.out.println("MATCH.");
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
    
    /*
     * Method: inserUser()
     * Description: Inserts a new user to the database
     *      + SQL INSERT statement (uses parameters to for variables)
     */
    protected void insertUser(String username, String password, String fName, String lName, String email) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "INSERT INTO helpdesk_schema.user_table " + "VALUES (0, '"+username+"', '"+password+"', 0, 0, '"+fName+"', '"+lName+"', '"+email+"')";
        System.out.println("Inserting new user: "+username);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: insertTicket()
     * Description: Inserts a new ticket to the database
     *      + SQL INSERT statement (uses parameters to for variables)
     */
    protected void insertTicket(String ticketTitle, String ticketDescription, int ticketNo, String ticketStatus, int userID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "INSERT INTO helpdesk_schema.ticket_table (`ticket_id`, `ticket_title`, `ticket_description`, `ticket_number`, `ticket_status`, `user_id`, `ticket_reply`) VALUES (0, '"+ticketTitle+"', '"+ticketDescription+"', '"+ticketNo+"', '"+ticketStatus+"', '"+userID+"', 'Awaiting Reply')";
        System.out.println("Inserting new ticket: "+ticketTitle);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: ticketCountUp()
     * Description: Adds 1 to user ticket count
     *      + SQL INSERT statement (uses parameters to for variables)
     */
    protected void ticketCountUp(int userID) throws SQLException {
        int ticketCount = getTicketCount(userID);
        ticketCount = ticketCount+1;
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.user_table SET user_noOfTickets = '"+ticketCount+"' WHERE (user_id = '"+userID+"')";
        System.out.println("Ticket count raised (by 1) for (userID): "+userID);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: ticketCountDown()
     * Description: Subtracts 1 from user ticket count
     *      + SQL INSERT statement (uses parameters to for variables)
     */
    protected void ticketCountDown(int userID) throws SQLException {
        int ticketCount = getTicketCount(userID);
        ticketCount = ticketCount-1;
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.user_table SET user_noOfTickets = '"+ticketCount+"' WHERE (user_id = '"+userID+"')";
        System.out.println("Ticket count raised (by 1) for (userID): "+userID);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: updateTicket()
     * Description: Updates a ticket's (specified by ticketID) description to the database
     *      + SQL UPDATE statement (uses parameters to for variables)
     */
    protected void updateTicket(String ticketDescription, int ticketID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.ticket_table SET ticket_description = '"+ticketDescription+"' WHERE ticket_id = "+ticketID;
        System.out.println("Updating ticket description (ticketID): "+ticketID);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: updateReply()
     * Description: Updates a ticket's (specified by ticketID) reply to the database
     *      + SQL UPDATE statement (uses parameters to for variables)
     */
    protected void updateReply(String ticketReply, int ticketID) throws SQLException{
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.ticket_table SET ticket_reply = '"+ticketReply+"' WHERE ticket_id = "+ticketID;
        System.out.println("Updating ticket reply (ticketID): "+ticketID);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: updatePriority()
     * Description: Updates a user's (specified by ticketID) priority to the database
     *      + SQL UPDATE statement (uses parameters to for variables)
     */
    protected void updatePriority(int userPriority, int userID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.user_table SET user_priority = '"+userPriority+"' WHERE user_id = "+userID;
        System.out.println("Updating user: "+userID+" to priority: "+userPriority);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: updateStatus()
     * Description: Updates a user's (specified by ticketID) status to the database
     *      + SQL UPDATE statement (uses parameters to for variables)
     */
    protected void updateStatus(String ticketStatus, int ticketID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "UPDATE helpdesk_schema.ticket_table SET ticket_status = '"+ticketStatus+"' WHERE ticket_id = "+ticketID;
        System.out.println("Updating ticket (ticketID): "+ticketID+" to ticket status: "+ticketStatus);
        statement.executeUpdate(sql);
    }
    
    /*
     * Method: deleteTicket()
     * Description: Deletes a ticket (specified by ticketID) from database
     *      + SQL DELETE statement (uses parameters to for variables)
     */
    protected void deleteTicket(int ticketID) throws SQLException {
        Statement statement = getConnection().createStatement();
        String sql;
        sql = "DELETE FROM helpdesk_schema.ticket_table WHERE (ticket_id ="+ticketID+")";
        System.out.println("Deleting ticket (ticketID): "+ticketID);
        statement.executeUpdate(sql);
    }
    
    
}
