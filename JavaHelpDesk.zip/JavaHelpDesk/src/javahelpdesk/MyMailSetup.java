/*
 * Name: MyMailSetup - Class
 * Description: Mail functionality
 *      +Used to send e-mails to users
 */
package javahelpdesk; 

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MyMailSetup {

	Properties emailProperties;
	Session mailSession;
	MimeMessage emailMessage;

        public MyMailSetup() throws AddressException,
			MessagingException {
            setMailServerProperties();
        }

	protected void setMailServerProperties() {

		String emailPort = "587";//gmail's smtp port

		emailProperties = System.getProperties();
		emailProperties.put("mail.smtp.port", emailPort);
		emailProperties.put("mail.smtp.auth", "true");
		emailProperties.put("mail.smtp.starttls.enable", "true");

	}
        
        /*
         * Method: These methods set the appropriate email subject & body for createEmailMessage(). Then sends email.
         * Description: Sets email, email subject & email body. 
         */
        protected void userRegisteredEmail(String email, String username) throws AddressException,
			MessagingException {
            String subject = "You have successfully registered!";
            String body = "<h1>Welcome "+username+"!</h1><h3>You have successfully registered on the Java Helpdesk Application.</h3><br>"
                    + "<h5>Please do not reply to this e-mail address. This email serves as notifications only; emails sent to this address are not monitored.</h5>";
            createEmailMessage(email, subject, body);
            sendEmail();
        }
        protected void ticketCreatedEmail(String email, String username, int ticketNo, String ticketTitle, String ticketDescription) throws AddressException,
			MessagingException {
            String subject = "Ticket "+ticketNo+" Created";
            String body = "<h1>Ticket "+ticketNo+" Created</h1>"+
                    "<h3>Your ticket has been created. An admin will be in touch ASAP(an email will be sent). You may log in to close the ticket if your issue is no longer pertinent. Your ticket details can be seen here: </h3><br>"+
                    "<h3>Title: "+ticketTitle+"</h3>"+
                    "<h3>Description: "+ticketDescription+"</h3><br>"+
                    "<h5>Please do not reply to this e-mail address. This email serves as notifications only; emails sent to this address are not monitored.</h5>";
            createEmailMessage(email, subject, body);
            sendEmail();
        }
        protected void adminReplyEmail(String email, String username, int ticketNo, String ticketTitle, String ticketDescription, String adminReply) throws AddressException,
			MessagingException {
            String subject = "Received reply for ticket: "+ticketNo;
            String body = "<h1>Ticket "+ticketNo+" Reply</h1>"+
                    "<h3>An admin has replied regarding your issue. You may log in to respond. Details:</h3>"+
                    "<h3>Title: "+ticketTitle+"</h3>"+
                    "<h3>Description: "+ticketDescription+"</h3>"+
                    "<h3>Reply: "+adminReply+"</h3><br>"+
                    "<h5>Please do not reply to this e-mail address. This email serves as notifications only; emails sent to this address are not monitored.</h5>";
            createEmailMessage(email, subject, body);
            sendEmail();
        }
        protected void ticketResolvedEmail(String email, String username, int ticketNo) throws AddressException,
			MessagingException {
            String subject = "Ticket: "+ticketNo+" has been marked as resolved.";
            String body = "<h1>Ticket "+ticketNo+" Resolved</h1>"+
                    "<h3>An admin has marked your ticket issue as resolved.</h3><br>"+
                    "<h5>Please do not reply to this e-mail address. This email serves as notifications only; emails sent to this address are not monitored.</h5>";
            createEmailMessage(email, subject, body);
            sendEmail();
        }
        protected void ticketClosedEmail(String email, String username, int ticketNo) throws AddressException,
			MessagingException {
            String subject = "Ticket: "+ticketNo+" has been closed.";
            String body = "<h1>Ticket "+ticketNo+" Closed</h1>"+
                    "<h3>You have closed your ticket. Thank you for using Java Help Desk.</h3><br>"+
                    "<h5>Please do not reply to this e-mail address. This email serves as notifications only; emails sent to this address are not monitored.</h5>";
            createEmailMessage(email, subject, body);
            sendEmail();
        }

	protected void createEmailMessage(String email, String subject, String body) throws AddressException,
			MessagingException {
		String[] toEmails = { email };
		String emailSubject = subject;
		String emailBody = body;

		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);

		for (int i = 0; i < toEmails.length; i++) {
			emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
		}

		emailMessage.setSubject(emailSubject);
		emailMessage.setContent(emailBody, "text/html");//for a html email
		//emailMessage.setText(emailBody);// for a text email

	}

	protected void sendEmail() throws AddressException, MessagingException {

		String emailHost = "smtp.gmail.com";
		String fromUser = "javaHelpdeskService";//just the id alone without @gmail.com
		String fromUserEmailPassword = "QRA5WPbOCHdq23epWQAS";

		Transport transport = mailSession.getTransport("smtp");

		transport.connect(emailHost, fromUser, fromUserEmailPassword);
		transport.sendMessage(emailMessage, emailMessage.getAllRecipients());
		transport.close();
		System.out.println("Email sent successfully.");
	}
}