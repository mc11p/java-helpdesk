/*
 * Name: AdminPanel - Class
 * Description: Handles Admin ticket management functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;

/**
 *
 * @author B00297681
 */
public class AdminPanel extends MySQLConnection {
    

}
