/*
 * Name: ClientTicketPanelGUI - JFrame Panel
 * Description: Ticket functionality
 *      +Instantiates ClientTicketPanel class for database interaction
 */
package javahelpdesk;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author B00297681
 */
public class ClientTicketPanelGUI extends javax.swing.JFrame {
    
    private int ticketNo; // ticket number
    private int ticketID; // ticket ID
    private boolean noReply; // flag that indicates existence of admin reply
    private String username; 
    private int userID;
    private ClientTicketPanel ticketPanel; // ClientTicketPanel class instance
    
    
    /**
     * Creates new form TicketPanelGUI
     */
    public ClientTicketPanelGUI() {
        initComponents();
        setTitle("Client Ticket Panel");
    }

    /*
     * Method: setLocalVariables()
     * Description: Set Class Variables. Makes username & ticket number visible in GUI label. Calls next method
     */
    protected void setLocalVariables(int ticketNo, String username, int userID) {
        this.ticketNo = ticketNo;
        this.username = username;
        this.userID = userID;
        ticketPanel = new ClientTicketPanel(ticketNo, this);
        ticketLabel.setText(username+" Ticket: "+ticketNo); // append username & ticket number to GUI panel label
        setTicketDetails(); // call method to set ticket details
    }

    /*
     * Method: setTicketDetails()
     * Description: Sets ticket title, description & reply fields with String returned from ticketPanel method calls.
     */
    protected void setTicketDetails() {
        try {
            // get ticketID 
            this.ticketID = ticketPanel.getTicketID(ticketNo, userID);

            // set text for ticket title, description & reply
            titleField.setText(ticketPanel.getTicketTitle(userID, ticketNo)); // calls ticketPanel class which extends MySQLConnection to handle data fetch: getTicketTitle()
            descriptionField.setText(ticketPanel.getTicketDescription(userID, ticketNo));
            replyField.setText(ticketPanel.getTicketReply(userID, ticketNo));

            setTicketButtons();

        } catch (SQLException ex) {
            Logger.getLogger(ClientPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /*
     * Method: setTicketButtons()
     * Description: Sets ticket buttons accordingly.
     *      +Disables Close Button for new tickets
     *      +Disables 'edibitable' on ticket title & description fields for submitted tickets. 
     *      +Sets noReply variable (see submitButtonActionPerformed() method for details on this variable)
     *      +Disables submit button if ticket is awaiting response
     */
    protected void setTicketButtons() {
        // set title Field uneditable ( & disable close button ) if ticket has a title 
        if(!titleField.getText().equals("No Ticket")) {
            titleField.setEditable(false);
        } else {
            titleField.setEditable(true);
            closeButton.setEnabled(false);
            titleField.setText("");
        }

        // set noReply to true if the ticket has no reply
        try {
            if (replyField.getText().equals("Awaiting Reply")) {
                noReply = true;
            } else if(ticketPanel.getTicketStatus(userID, ticketNo).equals("Awaiting Reply")) {
                noReply = true;
            } else if (ticketPanel.getTicketStatus(userID, ticketNo).equals("Client Reply")) {
                noReply = true;
            } else if (ticketPanel.getTicketStatus(userID, ticketNo).equals("Admin Reply")) {
                noReply = false;
                submitButton.setText("Update Ticket");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        

        // disable Submit Button if ticket description is not empty & awaiting reply
        System.out.println(noReply);
        if(!titleField.getText().equals("") && noReply) {
                submitButton.setEnabled(false);
                descriptionField.setEditable(false);
        }
            
        try {
            // enable Submit Button if ticket received admin reply. Change submit button to "Submit Reply"
            if(ticketPanel.getTicketStatus(userID, ticketNo).equals("Admin Reply")) {
                submitButton.setEnabled(true);
                submitButton.setText("Submit Reply");
                descriptionField.setEditable(true);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ticketLabel = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        titleField = new javax.swing.JTextField();
        descriptionLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        descriptionField = new javax.swing.JTextArea();
        submitButton = new javax.swing.JButton();
        closeButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        replyField = new javax.swing.JTextArea();
        replyLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ticketLabel.setText("Ticket Panel");

        titleLabel.setText("Ticket Title:");

        titleField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleFieldActionPerformed(evt);
            }
        });

        descriptionLabel.setText("Ticket Description:");

        descriptionField.setColumns(20);
        descriptionField.setRows(5);
        jScrollPane1.setViewportView(descriptionField);

        submitButton.setText("Submit Ticket");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        closeButton.setText("Close Ticket");
        closeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeButtonActionPerformed(evt);
            }
        });

        backButton.setText("Back to Panel");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        replyField.setEditable(false);
        replyField.setColumns(20);
        replyField.setRows(5);
        jScrollPane2.setViewportView(replyField);

        replyLabel.setText("Admin Reply:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(replyLabel)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(descriptionLabel)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(closeButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 283, Short.MAX_VALUE)
                            .addComponent(submitButton))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(titleLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1)
                        .addComponent(jScrollPane2)))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ticketLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backButton)
                .addGap(35, 35, 35))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ticketLabel)
                    .addComponent(backButton))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titleLabel)
                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(descriptionLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitButton)
                    .addComponent(closeButton))
                .addGap(48, 48, 48)
                .addComponent(replyLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void titleFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleFieldActionPerformed

    /*
     * Method: submitButtonActionPerformed()
     * Description: Submits or Updates a ticket(updating only changes the description). A prompt is displayed for confirmation (yes/no/close). 
     */
    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        String updateOrSubmit;
        if(noReply) { // if the ticket has noReply then the ticket Submit button is classified as 'Submit'
            updateOrSubmit = "Submit";
        } else { // if the ticket has a reply then the ticket Submit button is classifed as 'Update' (e.g a ticket exists but the user is updating the description after a reply)
            updateOrSubmit = "Update";
        }
        int response = JOptionPane.showConfirmDialog(null, updateOrSubmit+" Ticket?", "Confirm",
        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch (response) {
            case JOptionPane.NO_OPTION:
                System.out.println("No button clicked");
                break;
            case JOptionPane.YES_OPTION:
                System.out.println("Yes button clicked");
                if(noReply) {
                    try {
                        ticketPanel.insertTicket(titleField.getText(),descriptionField.getText(),ticketNo,"Awaiting Reply",userID);
                        ticketPanel.ticketCountUp(userID);
                        // send email (gets user email) 
                        String email = ticketPanel.getUserEmail(username);
                        MyMailSetup sendMail = new MyMailSetup();
                        sendMail.ticketCreatedEmail(email, username, ticketNo, titleField.getText(), descriptionField.getText()); // calls method to send submit email
                        submitButton.setEnabled(false);
                    } catch (SQLException | MessagingException ex) {
                        Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    try {
                        ticketPanel.updateTicket(descriptionField.getText(), ticketID);
                        ticketPanel.updateStatus("Client Reply", ticketID);
                        submitButton.setEnabled(false);
                    } catch (SQLException ex) {
                        Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
            case JOptionPane.CLOSED_OPTION:
                System.out.println("JOptionPane closed");
                break;
            default:
                break;
        }
    }//GEN-LAST:event_submitButtonActionPerformed

    /*
     * Method: closetButtonActionPerformed()
     * Description: Deletes the ticket displayed in the GUI. A prompt is displayed for confirmation (yes/no/close).
     */
    private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeButtonActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, "Do you wish to close the ticket?", "Confirm",
        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        switch (response) {
            case JOptionPane.NO_OPTION:
                System.out.println("No button clicked");
                break;
            case JOptionPane.YES_OPTION:
                System.out.println("Yes button clicked");
                try {
                    ticketPanel.deleteTicket(ticketID);
                    ticketPanel.ticketCountDown(userID);
                    String email = ticketPanel.getUserEmail(username);
                    MyMailSetup sendMail = new MyMailSetup();
                    sendMail.ticketClosedEmail(email, username, ticketNo); // calls method to send resolve email
                    ClientPanelGUI clientGUI = new ClientPanelGUI();
                    clientGUI.setVisible(true);
                    clientGUI.setUsername(username);
                    dispose();
                } catch (SQLException | MessagingException ex) {
                    Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                break;
            case JOptionPane.CLOSED_OPTION:
                System.out.println("JOptionPane closed");
                break;
            default:
                break;
        }
    }//GEN-LAST:event_closeButtonActionPerformed

    /*
     * Method: backButtonActionPerformed()
     * Description: Navigates back to the Client Panel 
     */
    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        ClientPanelGUI clientGUI = new ClientPanelGUI();
        clientGUI.setVisible(true);
        clientGUI.setUsername(username);
        dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientTicketPanelGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientTicketPanelGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JButton closeButton;
    private javax.swing.JTextArea descriptionField;
    private javax.swing.JLabel descriptionLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea replyField;
    private javax.swing.JLabel replyLabel;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel ticketLabel;
    private javax.swing.JTextField titleField;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration//GEN-END:variables
}
