/*
 * Name: AdminSelectPanel - Class
 * Description: Handles Admin functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;

/**
 *
 * @author B00297681
 */
public class AdminSelectPanel extends MySQLConnection {
    
}
