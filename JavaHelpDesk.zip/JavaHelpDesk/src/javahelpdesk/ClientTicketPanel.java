/*
 * Name: ClientTicketPanel - Class
 * Description: Handles Ticket functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;

/**
 *
 * @author B00297681
 */
public class ClientTicketPanel extends MySQLConnection { 
    private ClientTicketPanelGUI ticketGUI;
    private int ticketNo;
    
    // constructor which sets local variables
    public ClientTicketPanel(int ticketNo, ClientTicketPanelGUI ticketGUI) {
        this.ticketNo = ticketNo;
        this.ticketGUI = ticketGUI;
    }   
}
