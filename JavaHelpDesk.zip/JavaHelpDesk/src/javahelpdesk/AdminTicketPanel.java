/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javahelpdesk;

/**
 *
 * @author B00297681
 */
public class AdminTicketPanel extends MySQLConnection {
    private AdminTicketPanelGUI ticketGUI;
    private int ticketNo;
    
    // constructor which sets local variables
    public AdminTicketPanel(int ticketNo, AdminTicketPanelGUI ticketGUI) {
        this.ticketNo = ticketNo;
        this.ticketGUI = ticketGUI;
    }   
}
