/*
 * Name: LogInPanel - Class
 * Description: Handles Log In functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;
import java.sql.*;
/**
 * @author B00297681
 */
public class LogInPanel extends MySQLConnection {
    
    private String username;
    private String password;
    private LogInPanelGUI logGUI;
    

    public LogInPanel(String username, String password, LogInPanelGUI logGUI) {
        this.username=username;
        this.password=password;
        this.logGUI=logGUI;
    }
    
    protected boolean AuthenticateUser(String username, String password) throws SQLException {
        return usernameExists(username) && passwordExists(password, username);
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
    }
    
}
