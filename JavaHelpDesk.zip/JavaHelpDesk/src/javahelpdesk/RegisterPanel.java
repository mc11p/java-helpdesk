/*
 * Name: RegisterPanel - Class
 * Description: Handles RegisterPanel functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author B00297681
 */
public class RegisterPanel extends MySQLConnection {
    
    private String username;
    private String password;
    private String rePassword;
    private RegisterPanelGUI registerGUI;
    private String email_Regex = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
    private Pattern pattern;
    private Matcher matcher;
    
    public RegisterPanel(String username, String password, String rePassword, RegisterPanelGUI registerGUI) {
        this.username=username;
        this.password=password;
        this.rePassword=rePassword;
        this.registerGUI=registerGUI;
        pattern = Pattern.compile(email_Regex, Pattern.CASE_INSENSITIVE);
    }
    
    /*
     * Method: checkAll
     * Description: Validates Username, Password & Email...
     *      returns 0 for Invalid Username
     *      returns 1 for Invalid Password
     *      returns 2 for Password Mismatch
     *      returns 3 for Invalid Email
     *      returns 4 for successful validation.
     */
    public int checkAll(String username, String password, String rePassword, String email) {
        if (!checkUsername(username)) {
            return 0; 
        } else if (!checkPassword(password)) {
            return 1;
        } else if (!passwordMatch(password, rePassword)) {
            return 2;
        } else if (!checkEmail(email)) {
            return 3;
        } else {
            return 4;
        }
    }
    
    /*
     * Method: checkUsername
     * Description: Validates username by checking that...
     *      length is between 5 & 25 characters
     *      contains no numbers
     */
    public boolean checkUsername(String username) {
        if(username.length()>=3 && username.length()<=25) { //check length boundary
            for(int x=0; x<username.length();x++) { //check string for digit check
                char y; //character used to store String username characters
                y = username.charAt(x); 
                if (Character.isDigit(y)) { //is digit? If so, return false as it is not allowed
                    return false; //reutrns false - length boundary(true) && digit check(true)
                }
            }
            return true; //returns true - length boundary(true) && digit check(false)
        }
        return false; //returns false - length boundary(false)
    }
    
    /*
     * Method: checkPassword
     * Description: Validates password by checking that...
     *      length is between 5 & 25 characters
     *      contains at least 1 number
     *      similar to checkUsername method but REQUIRES a number instead
     */
    public boolean checkPassword(String password) {
        if(password.length()>=5 && password.length()<=25) { //check length boundary
            for(int x=0; x<password.length();x++) { //check string for digit check
                char y; //character used to store String password characters
                y = password.charAt(x); 
                if (Character.isDigit(y)) { //is digit? If so, return true as it is required
                    return true; //returns true - length boundary(true) && digit check(true)
                }
            }
            return false; //returns false - length boundary(true) && digit check(false)
        }
        return false; //returns false - length boundary(false)
    }
    
    /*
     * Method: checkEmail
     * Description: Validates email by matching against an Email regex pattern
     * Uses util.regex.Matcher & util.regex.Pattern for this
     * Pattern created at the top of the class & compiled in the constructor.
     */
    public boolean checkEmail(String email) {
        return pattern.matcher(email).matches();
    }
    
    /*
     * Method: passwordMatch
     * Description: Checks if password is inputted twice correctly.
     */
    public boolean passwordMatch(String password, String confirmPassword) {
        if(password.equals(confirmPassword)) {
            return true;
        }
        return false;
    }
    
    public void Register() {
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
}

