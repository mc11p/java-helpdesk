/*
 * Name: ClientPanel - Class
 * Description: Handles Client Ticket functionality 
 *      +Extends MySQLConnection
 */
package javahelpdesk;
import java.sql.*;

/**
 *
 * @author B00297681
 */
public class ClientPanel extends MySQLConnection {
    private String username;
    private ClientPanelGUI clientGUI;
    
    public ClientPanel(String username, ClientPanelGUI clientGUI) {
        this.username = username;
        this.clientGUI = clientGUI;
    }
}
